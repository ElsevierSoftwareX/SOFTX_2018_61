library(testthat)
library(biogas)

test_check("biogas")
