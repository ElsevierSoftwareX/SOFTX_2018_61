# biogas
Tools for biogas research in R: process biogas data and predict biogas production

# Branch organization
* dev: main development branch for work on package
* master: merged with dev before submission to CRAN
* version number branches (e.g., 10.0.2): archived versions that are available on CRAN
